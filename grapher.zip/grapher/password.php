<?php
	$password = "14skm4s13r";
?>